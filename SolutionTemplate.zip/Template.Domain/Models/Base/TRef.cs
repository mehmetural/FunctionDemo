﻿namespace $safeprojectname$.Models.Base
{
    public class TRef
    {
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
    }
}
