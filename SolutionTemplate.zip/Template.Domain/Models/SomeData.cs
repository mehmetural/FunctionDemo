﻿namespace $safeprojectname$.Models
{
    public class SomeData : EntityBase
    {
        public string Data { get; set; }
    }
}
